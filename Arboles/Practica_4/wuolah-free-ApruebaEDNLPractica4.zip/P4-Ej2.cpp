/*
* 2. Añade al TAD Abb un operador de conversión para obtener un árbol binario a partir
*    de un ABB, template <typename T> Abb<T>::operator Abin<T>() const;. Es
*    necesario declararlo como amigo de la clase Abin. Este operador nos permitirá obtener
*    una copia de un ABB y tratarlo como un árbol binario, por ejemplo para realizar un
*    recorrido del mismo.
*/

/* AÑADIR ESTE CÓDIGO AL TAD "Árbol binario de búsqueda" IMPLEMENTADO DE MEDIANTE UNA ESTRUCTURA DINÁMICA RECURSIVA */

template <typename T>
Abb<T>::operator Abin<T>()
{
    Abin<T> tmp;

    if (r != 0)    //si el arbol no está vacío
    {
        tmp.insertarRaizB(r->elto);
        rellenar(tmp.raizB(), tmp);
    }
    return tmp;
}


template<typename T>
void Abb<T>::rellenar(typename Abin<T>::nodo n, Abin<T> &A)
{
    if (r->izq.r != 0)
    {
        A.insertarHijoIzqdoB(n,r->izq.r->elto);
        r->izq.rellenar(A.hijoIzqdoB(n), A);
    }
    if (r->der.r != 0)
    {
        A.insertarHijoDrchoB(n,r->der.r->elto);
        r->der.rellenar(A.hijoDrchoB(n), A);
    }
}
