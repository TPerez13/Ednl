#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#include "abin.h"
#include "abin_E-S.h"
#include "abb.h"

/*
* 3. Un árbol binario de búsqueda se puede equilibrar realizando el recorrido en inorden
*    del árbol para obtener el listado ordenado de sus elementos y a continuación, repartir
*    equitativamente los elementos a izquierda y derecha colocando la mediana en la raíz y
*    construyendo recursivamente los subárboles izquierdo y derecho de cada nodo.
*    Implementa este algoritmo para equilibrar un ABB.
*/

//  POST: Equilibra un árbol Abb dado
template <typename T>
void equilibrarAbb(Abb<T> &A)
{
    Abb<T> tmp;

    if (!A.vacio())
    {
        std::vector<T> v;

        obtenerVector(v, A);      //ahora v contiene los elementos de A de forma ordenada
        rellenarAbb(v, tmp, 0, v.size()-1);    //también sería correcto nNodos(A)-1 como cuarto parámetro
    }
    A=tmp;                  //asignamos a A el árbol equilibrado equivalente a sí mismo.
}

//  POST:   Vector contiene un listado ordenado de todos los elementos contenidos en A.
//          Este listado ha sido obtenido mediante la extracción inordenada de los elementos que contiene A.
template <typename T>
void obtenerVector(std:: vector<T> &v, const Abb<T> &A)
{
    if (!A.vacio())
    {
        obtenerVector(v, A.izqdo());
        v.push_back(A.elemento());
        obtenerVector(v, A.drcho());
    }
}

//  PRE:    Vector contiene un listado ordenado de elementos
//  POST:   Se insertan en A los elementos de v comprendidos en el rango [min-max]; A es equilibrado.
template <typename T>
void rellenarAbb(std:: vector<T> &v, Abb<T> &A, int min, int max)
{
    int elemAInsertar= (max+min)/2;
    A.insertar(v[elemAInsertar]);
    if (min != max)             //(si min == max, entonces no tenemos que hacer más recursiones)
    {
        rellenarAbb(v,A, min, elemAInsertar);
        rellenarAbb(v,A, elemAInsertar+1, max);
    }
}



typedef int tElto;
const tElto fin = -99;


int main()
{
    Abb<tElto> busqA;
    Abin<tElto> A;

    // Insertamos los elementos de forma que el Abb se degenera en una lista:
    busqA.insertar(0);
    busqA.insertar(1);
    busqA.insertar(2);
    busqA.insertar(3);
    busqA.insertar(4);
    busqA.insertar(5);
    busqA.insertar(6);

    cout <<"---Imprimiendo A sin equilibrar:---" << endl;
    A= busqA; // Operador de conversión Abb -> Abin
    imprimirAbin(A); // Utilizamos la función de imprimir ABin

    cout <<"\n---Imprimiendo A equilibrado:---" << endl;
    equilibrarAbb(busqA);   //Equilibramos el Abb
    A= busqA;
    imprimirAbin(A);

return 0;
}
