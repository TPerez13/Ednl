#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#include "abin.h"
#include "abin_E-S.h"
#include "abb.h"

//Funciones que se necesitan para la resolución del problema: (El ejercicio 3 de esta misma práctica)

//  POST: Equilibra un árbol Abb dado
template <typename T>
void equilibrarAbb(Abb<T> &A)
{
    Abb<T> tmp;

    if (!A.vacio())
    {
        std::vector<T> v;

        obtenerVector(v, A);      //ahora v contiene los elementos de A de forma ordenada
        rellenarAbb(v, tmp, 0, v.size()-1);    //también sería correcto nNodos(A)-1 como cuarto parámetro
    }
    A=tmp;                  //asignamos a A el árbol equilibrado equivalente a sí mismo.
}

//  POST:   Vector contiene un listado ordenado de todos los elementos contenidos en A.
//          Este listado ha sido obtenido mediante la extracción inordenada de los elementos que contiene A.
template <typename T>
void obtenerVector(std:: vector<T> &v, const Abb<T> &A)
{
    if (!A.vacio())
    {
        obtenerVector(v, A.izqdo());
        v.push_back(A.elemento());
        obtenerVector(v, A.drcho());
    }
}

//  PRE:    Vector contiene un listado ordenado de elementos
//  POST:   Se insertan en A los elementos de v comprendidos en el rango [min-max]; A es equilibrado.
template <typename T>
void rellenarAbb(std:: vector<T> &v, Abb<T> &A, int min, int max)
{
    int elemAInsertar= (max+min)/2;
    A.insertar(v[elemAInsertar]);
    if (min != max)             //(si min == max, entonces no tenemos que hacer más recursiones)
    {
        rellenarAbb(v,A, min, elemAInsertar);
        rellenarAbb(v,A, elemAInsertar+1, max);
    }
}

/*
* 6. Implementa el operador ♦ para conjuntos definido como A ♦ B = (A ∪ B) - (A ∩ B).
*    La implementación del operador ♦ debe realizarse utilizando obligatoriamente la
*    operación ∈, que nos indica si un elemento dado pertenece o no a un conjunto. La
*    representación del tipo Conjunto debe ser tal que la operación de pertenencia esté en el
*    caso promedio en O(log n).
*/
//función auxiliar: Indica si un elemento pertenece a un árbol dado
template <typename T>
bool pertenece (const T &e, const Abb<T> A)
{
    return (!A.buscar(e).vacio());
}

template <typename T>
Abb<T> opRombito(const Abb<T> &A, const Abb<T> &B)
{
    Abb<T> tmp, auxA, auxB;

    auxA= A;
    auxB= B;

    while (!auxA.vacio())
    {
        if (pertenece(auxA.elemento(), B))
            auxB.eliminar(auxA.elemento());//Si la raíz de A PERTENECE a B, entonces la eliminamos de ambos árboles.
        else
            tmp.insertar(auxA.elemento());//Si la raíz de A NO PERTENECE a B, entonces la añadimos al árbol final.

        auxA.eliminar(auxA.elemento());     //una vez procesada la raíz de A, la eliminamos y dejamos que el árbol A se reordene
    } // Cuando salimos de este while, B solo contiene elementos exclusivos de B (se han desechado todos los comunes)

    while (!auxB.vacio())
    {
        tmp.insertar(auxB.elemento());
        auxB.eliminar(auxB.elemento());
    }

    equilibrarAbb(tmp); // Equilibramos el árbol
    return tmp;
}



typedef int tElto;
const tElto fin = -99;
/*
 * BATERÍA DE PRUEBAS (MAIN)
 */
int main()
{
    Abb<tElto> busqA;
    Abb<tElto> busqB;
    Abin<tElto> A;

    // Se insertan elementos en ambos árboles para luego construir la unión
    busqA.insertar(0);
    busqA.insertar(1);
    busqA.insertar(2);
    busqA.insertar(4);
    busqA.insertar(5);
    busqA.insertar(9);

    busqB.insertar(2);
    busqB.insertar(4);
    busqB.insertar(8);
    busqB.insertar(6);
    busqB.insertar(9);

    cout <<"---Imprimiendo A---" << endl;
    A= busqA;
    imprimirAbin(A);


    cout <<"\n---Imprimiendo B---" << endl;
    A= busqB;
    imprimirAbin(A);

    Abb<tElto> busqR= opRombito(busqA,busqB);

    cout <<"\n---Imprimiendo ROMBITO equilibrada:---" << endl;
    A= busqR;
    imprimirAbin(A);

    return 0;
}
