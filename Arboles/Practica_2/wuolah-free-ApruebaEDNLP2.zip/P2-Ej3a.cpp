/* VERSIÓN VOID EMPLEANDO SALIDA ESTÁNDAR */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <cmath>
#include "abin.h"
#include "abin_E-S.h"

using namespace std;

/*
* 3. El TAD árbol binario puede albergar expresiones matemáticas mediante un árbol de
* expresión. Dentro del árbol binario los nodos hojas contendrán los operandos, y el resto
* de los nodos los operadores:
*/

/*
*   a)  Define el tipo de los elementos del árbol para que los nodos puedan almacenar
*       operadores y operandos.
*
*           Los nodos del árbol almacenarán un CARÁCTER que puede ser:
*           - Una cadena numérica de caracteres, si el nodo es una hoja (operando)
*           - Alguno de los siguientes caracteres, si el nodo tiene descendientes: + - * / (operador)
*           Por lo tanto, los elementos que almacene este árbol serán de tipo string
*
*           Como los operadores + - * / son todos binarios, es necesario que NINGÚN NODO tenga únicamente un hijo, es decir:
*           Todos los nodos han de ser hojas o bien tener dos hijos.
*/


/*
*   b)  Implementa una función que tome un árbol binario de expresión (aritmética) y
*       devuelva el resultado de la misma. Por simplificar el problema se puede asumir que el
*       árbol representa una expresión correcta. Los operadores binarios posibles en la
*       expresión aritmética serán suma, resta, multiplicación y división.
*/

double evaluarExpresion_rec(typename Abin<string>::nodo n, const Abin<string> &A)
{
    assert(n != Abin<string>::NODO_NULO); // Comprobamos que el nodo n no es nulo

    double res; //Variable donde se almacenará el resultado

        if (A.hijoIzqdoB(n)==Abin<string>::NODO_NULO && A.hijoDrchoB(n)==Abin<string>::NODO_NULO) // Si el nodo es hoja, podemos devolver el resultado de esta rama
        {
            res = (double)stoi(A.elemento(n));
            cout << res;
        }
        else
        {
                cout << "(";
            double operandoIzq = evaluarExpresion_rec(A.hijoIzqdoB(n), A);
                cout << A.elemento(n)[0];
            double operandoDer = evaluarExpresion_rec(A.hijoDrchoB(n), A);
                cout << ")";

            switch (A.elemento(n)[0]) //capturamos el primer (y único) carácter almacenado en el nodo n, que ya sabemos que no es una hoja
            {
                case '+': res = (operandoIzq + operandoDer);
                break;

                case '-': res = (operandoIzq - operandoDer);
                break;

                case '*': res = (operandoIzq * operandoDer);
                break;

                case '/': res = (operandoIzq / operandoDer);
                break;
            }
      }
      return res;
}

// Máscara de la función anterior
void evaluarExpresion(const Abin<string> &A)
{
    assert(!A.arbolVacioB());
    double res;

    res = evaluarExpresion_rec(A.raizB(), A);
    cout << " = " << res << endl;
}

int main()
{
    Abin<string> A;
    //PARA RELLENAR DESDE FICHERO:
        ifstream fA("expresion1.txt"); // Abrir fichero de entrada.
        rellenarAbin(fA,A); // Rellenar desde fichero.

    cout << "---Árbol A:---" << endl;
    imprimirAbin(A);
    cout << "Evaluamos la expresión aritmética:" << endl;
    evaluarExpresion(A);

    return 0;
}
