#include <cstdlib>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include "abin.h"
#include "abin_E-S.h"

using namespace std;


/*
* 2. Para un árbol binario B, podemos construir el árbol binario reflejado B' cambiando
* los subárboles izquierdo y derecho en cada nodo. Implementa un subprograma que
* devuelva el árbol binario reflejado de uno dado.
*/
template <typename T>
Abin<T>& reflejado(const Abin<T> &A)
{
    Abin<T> *B = new Abin<T>;

    if (A.raizB() != Abin<T>::NODO_NULO)
    {
        B->insertarRaizB(A.elemento(A.raizB()));
        reflejado_rec(A.raizB(), B->raizB(), A, *B);
    }
    return *B;
}

template <typename T>
void reflejado_rec(typename Abin<T>::nodo n1, typename Abin<T>::nodo n2, const Abin<T> &A, Abin<T> &B)
{
    if (A.hijoIzqdoB(n1) != Abin<T>::NODO_NULO)
    {
        B.insertarHijoDrchoB(n2, A.elemento(A.hijoIzqdoB(n1)));
        reflejado_rec(A.hijoIzqdoB(n1), B.hijoDrchoB(n2), A, B);
    }

    if (A.hijoDrchoB(n1) != Abin<T>::NODO_NULO)
    {
        B.insertarHijoIzqdoB(n2, A.elemento(A.hijoDrchoB(n1)));
        reflejado_rec(A.hijoDrchoB(n1), B.hijoIzqdoB(n2), A, B);
    }
}



/*PARA USAR ÁRBOLES DE CARACTERES:*/
    typedef char tElto;
    tElto fin = '#';
/*PARA USAR ÁRBOLES DE ENTEROS:*/
//  typedef int tElto;
//  tElto fin = -99;
int main()
{
    Abin<tElto> A;

    //PARA RELLENAR DESDE FICHERO:
        ifstream fA("abin2-char.txt"); // Abrir fichero de entrada.
        rellenarAbin(fA,A); // Rellenar desde fichero.
    //PARA RELLENAR MANUALMENTE:
    //    rellenarAbin(A, fin);

    cout << "---Árbol A:---" << endl;
    imprimirAbin(A);
    cout << "---Reflejo del árbol A:---" << endl;
    imprimirAbin(reflejado(A));

    return 0;
}
