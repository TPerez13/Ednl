/* Ejercicio 4:

    Simplemente en este ejercicio están pidiendo la implementación pseudoestática del TAD "Árbol binario"
    mediante un vector de posiciones relativas, dado en las clases de teoría. Esta implementación está subida
    al campus por los profesores.
*/
