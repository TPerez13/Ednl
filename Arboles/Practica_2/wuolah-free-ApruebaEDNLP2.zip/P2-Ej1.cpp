#include <cstdlib>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include "abin.h"
#include "abin_E-S.h"

using namespace std;


/*
* 1. Dos árboles binarios son similares cuando tienen idéntica estructura de ramificación,
* es decir, ambos son vacíos, o en caso contrario, tienen subárboles izquierdo y derecho
* similares. Implementa un subprograma que determine si dos árboles binarios son
* similares.
*/
template<typename T1, typename T2> //Los árboles pueden incluso ser de distinta clase
bool sonSimilares(Abin<T1>&A1, Abin<T2>&A2)
{
    return sonSimilares_rec(A1.raizB(), A2.raizB(), A1, A2);
}

template<typename T1, typename T2>
bool sonSimilares_rec(typename Abin<T1>::nodo n1, typename Abin<T2>::nodo n2, const Abin<T1> &A1, const Abin<T2> &A2)
{
    if (n1 == Abin<T1>::NODO_NULO && n2 == Abin<T2>::NODO_NULO)
        return true;
    else if (n1 != Abin<T1>::NODO_NULO && n2 != Abin<T2>::NODO_NULO)
        return (sonSimilares_rec(A1.hijoIzqdoB(n1), A2.hijoIzqdoB(n2), A1, A2) && sonSimilares_rec(A1.hijoDrchoB(n1), A2.hijoDrchoB(n2), A1, A2));
    else
        return false;
}




int main()
{
    Abin<char> A;
    Abin<int> B;
    //PARA RELLENAR DESDE FICHERO:
        ifstream fA("abin1-char.txt"); // Abrir fichero de entrada.
        ifstream fB("abin1-int.txt");
        rellenarAbin(fA,A); // Rellenar desde fichero.
        rellenarAbin(fB,B);

    cout << "---Árbol A:---" << endl;
    imprimirAbin(A);
    cout << "---Árbol B:---" << endl;
    imprimirAbin(B);

    
    if (sonSimilares(A,B))
        cout << "Los árboles son similares" << endl;
    else
        cout << "Los árboles NO son similares" << endl;


    return 0;
}
