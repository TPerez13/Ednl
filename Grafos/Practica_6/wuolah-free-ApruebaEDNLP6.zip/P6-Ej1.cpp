/* 1.
Añadir una función genérica, llamada DijkstraInv , en el fichero
alg_grafoPMC.h para resolver el problema inverso al de Dijkstra, con los mismos
tipos de parámetros y de resultado que la función ya incluida para éste. La nueva
función, por tanto, debe hallar el camino de coste mínimo hasta un destino desde cada
vértice del grafo y su correspondiente coste.
*/

/*
    Añadir esta función al fichero alg_grafoPMC.h:
*/

template <typename tCoste>
vector<tCoste> DijkstraInv( const GrafoP<tCoste>& G,
                            typename GrafoP<tCoste>::vertice destino,
                            vector<typename GrafoP<tCoste>::vertice>& P)
{
    typedef typename GrafoP<tCoste>::vertice vertice;
    size_t n = G.numVert();

    // Creamos e inicializamos las EEDD necesarias para realizar el Dijkstra Inverso
    vector<tCoste> D(n);    // Vector de costes
    P = vector<vertice>(n);  // Vector de vértices

    // Creamos las EEDD necesarias para llamar a la función Floyd:
    matriz<tCoste> A(n);       // creación de la matriz de costes mínimos
    matriz<vertice> PFloyd(n);  // creación de la matriz de vértices

    // Llamamos a Floyd y capturamos resultados:
    A = Floyd(G, PFloyd);

    //Una vez tenemos el resultado de Floyd, nos quedamos con la destino-ésima
    //columna de cada una de las matrices devueltas por el algoritmo de Floyd.
    //Estas columnas son resultado de nuestro Dijkstra inverso:
    for(int i=0; i<n; i++){
        D[i] = A[i][destino];
        P[i] = PFloyd[i][destino];

        if(P[i]==i) P[i] = destino;
    }   //Este if es para arreglar una inconsistencia, que se da cuando el camino
        //de menor coste del vértice i hacia el destino fuera un camino directo.
    return D;
}
