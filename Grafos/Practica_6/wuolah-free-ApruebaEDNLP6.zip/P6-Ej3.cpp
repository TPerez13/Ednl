#include <iostream>
#include "matriz.h"
#include "grafoPMC.h"
#include "alg_grafoPMC.h"

using namespace std;

/*
3. Tu empresa de transportes “PEROTRAVEZUNGRAFO S.A.” acaba de recibir la
lista de posibles subvenciones del Ministerio de Fomento en la que una de las más
jugosas se concede a las empresas cuyo grafo asociado a su matriz de costes sea
acíclico. ¿Puedes pedir esta subvención?
Implementa un subprograma que a partir de la matriz de costes nos indique si tu
empresa tiene derecho a dicha subvención.
*/

/*
El problema nos pide que implementemos la siguiente función
    template <typename T>               PRE: G es una matriz de costes asociada a un grafo
    bool esAciclico(GrafoP<T> &G);      POST: Devuelve "true" si y solo si el grafo asociado a la matriz es acíclico.


    IMPORTANTE: El algoritmo diseñado está basado en este método para comprobar si un grafo es acíclico:
                    https://www.cs.hmc.edu/~keller/courses/cs60/s98/examples/acyclic/
                Si no te lees la página, probablemente no entiendas por qué el código funciona
*/



//Dado un grafo y un vértice perteneciente a este, determina si ese nodo es una hoja
template <typename T>
bool esHoja(const typename GrafoP<T>::vertice v, const GrafoP<T> &G)
{
    size_t i= 0;
    bool loEs= true;

    while (i < G.numVert() && loEs)
    {
        loEs= (G[v][i] == GrafoP<T>::INFINITO);
        i++;
    }
    return loEs;
}

//Dado un grafo y un vértice perteneciente a este, modifica el grafo para que el vértice quede podado.
//(al podar el vértice V, eliminamos todas las aristas que tienen V como destino)
template <typename T>
void podar(const typename GrafoP<T>::vertice v, GrafoP<T> &G)
{
    size_t i;

    for(i=0; i<G.numVert(); i++)
        G[i][v]= GrafoP<T>::INFINITO;
}

// Dado un grafo ponderado, se devuelve true si y solo si el grafo es acíclico
template <typename T>
bool esAciclico(const GrafoP<T> &g)
{
    GrafoP<T> G= g; // Recibimos el Grafo g, y para no modificarlo, lo copiamos en el Grafo G
    typename GrafoP<T>::vertice v = 0;
    size_t nPodados=0;
    bool vPodado[G.numVert()]={false}; // vPodado[i] contiene true si y solo si el vértice i ha sido podado (tras comprobar que es una hoja)

    while(v<G.numVert())
    {
        if(esHoja(v,G) && !vPodado[v])  //si hemos encontrado una hoja que aun no hemos podado, entonces la podamos y empezamos a evaluar desde el principio
        {
            vPodado[v]= true;
            nPodados++;
            podar(v,G);
            v= -1;
        }
        v++;  //v se resetea a 0 si hemos pasado por el if; Si no hemos entrado en el if entonces solo avanzamos hacia adelante
    }
return (nPodados==G.numVert()); // Si hemos podido podar la totalidad del grafo, significa que el grafo era acíclico.
}



//MAIN---------------------------------
int main()
{
    const char* cad= "g3.txt";
    GrafoP<unsigned int> g(cad);

    if (esAciclico(g)) cout<<g<<" Es acíclico"<<endl;
    else               cout<<g<<" NO es acíclico"<<endl;

return 0;
}
