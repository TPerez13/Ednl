/*
2. Definiremos el pseudocentro de un grafo conexo como el nodo del mismo que minimiza la suma de las distancias mínimas a sus dos nodos más alejados.
Definiremos el diámetro del grafo como la suma de las distancias mínimas a los dos nodos más alejados del pseudocentro del grafo.
Dado un grafo conexo representado mediante matriz de costes, implementa un subprograma que devuelva la longitud de su diámetro.
*/


#include "matriz.h"
#include "grafoPMC.h"
#include "alg_grafoPMC.h"
#include <iostream>
#include <limits>
using namespace std;

template<typename T>
typename GrafoP<T>::tCoste diametro(GrafoP<T> &G)
{
    matriz<typename GrafoP<T>::vertice> rutas;                  //matriz auxiliar, no la usaremos pero la necesitamos para llamar a floyd
    matriz<typename GrafoP<T>::tCoste>  costes= Floyd(G,rutas); //matriz de costes

    typename GrafoP<T>::vertice pseudo;                         //vertice candidato a pseudocentro
    typename GrafoP<T>::tCoste diametro=  GrafoP<T>::INFINITO;  //coste candidato a diámetro

    T max1= std::numeric_limits<T>::min(), max2=max1, aux;   //maxima, y segundo máxima distancia (inicializados al mínimo valor posible). Var. auxiliar.
    size_t i;

    for (pseudo=0; pseudo<G.numVert(); pseudo++)        //calculamos el pseudocentro
    {
        for(i=0; i<G.numVert(); i++)
        {
            if (costes[pseudo][i] != GrafoP<T>::INFINITO)
            {
                max2= max(max2, costes[pseudo][i]);
                if (max2>max1)  //de este modo siempre nos aseguramos que max1 contiene el mayor y max2 contiene el segundo mayor
                {
                    aux= max1;  max1=max2;  max2= aux;
                }
            }
        }//tras terminar este for, tenemos las dos distancias más grandes
        cout<<"Distancias desde "<<pseudo<<" hasta los nodos más alejados: "<<max1<<" - "<<max2<<endl;
        diametro= min(diametro, suma(max1,max2));       //obtenemos el mínimo diámetro encontrado hasta ahora
        max1= std::numeric_limits<T>::min(), max2=max1; //reseteamos los contadores de mínimo y máximo
    }
    return diametro;
}


//MAIN---------------------------------
int main()
{
    GrafoP<unsigned int> G("gNoDiri.txt");

    cout << "--- Grafo G ---" <<endl;
    cout << G << endl;

    cout << "Búsqueda del pseudocentro: " <<endl;
    typename GrafoP<unsigned int>::tCoste diam = diametro(G);
    cout<< "\nDiámetro: "<< diam << endl;

return 0;
}
