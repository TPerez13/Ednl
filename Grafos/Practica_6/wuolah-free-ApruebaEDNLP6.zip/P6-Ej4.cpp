#include "matriz.h"
#include "listaenla.h"
#include "grafoPMC.h"
#include "alg_grafoPMC.h"
#include "alg_grafo_E-S.h"
#include <iostream>
#include <limits>

using namespace std;

/*
4. Se necesita hacer un estudio de las distancias mínimas necesarias para viajar entre
dos ciudades cualesquiera de un país llamado Zuelandia. El problema es sencillo pero
hay que tener en cuenta unos pequeños detalles:
a) La orografía de Zuelandia es un poco especial, las carreteras son muy estrechas
y por tanto solo permiten un sentido de la circulación.
b) Actualmente Zuelandia es un país en guerra. Y de hecho hay una serie de
ciudades del país que han sido tomadas por los rebeldes, por lo que no pueden
ser usadas para viajar.
c) Los rebeldes no sólo se han apoderado de ciertas ciudades del país, sino que
también han cortado ciertas carreteras, (por lo que estas carreteras no pueden ser
usadas).
d) Pero el gobierno no puede permanecer impasible ante la situación y ha exigido
que absolutamente todos los viajes que se hagan por el país pasen por la capital
del mismo, donde se harán los controles de seguridad pertinentes.
Dadas estas cuatro condiciones, se pide implementar un subprograma que dados
    - el grafo (matriz de costes) de Zuelandia en situación normal,
    - la relación de las ciudades tomadas por los rebeldes,
    - la relación de las carreteras cortadas por los rebeldes, y
    - la capital de Zuelandia
calcule la matriz de costes mínimos para viajar entre dos ciudades zuelandesas
cualesquiera en esta situación.


    FUNCIONAMIENTO DEL ALGORITMO DISEÑADO:
    -Una vez obtenidos los argumentos necesarios (mapa de Zuelandia, ciudades y
    carreteras tomadas, y capital de Zuelandia), modificamos el mapa para que NO
    puedan utilizarse como destino las ciudades tomadas, y tampoco puedan utilizarse
    carreteras tomadas.

    -Con Dijkstra inverso, obtenemos los costes mínimos de viajar desde cualquier
    ciudad hasta la capital (en un vector llamado haciaLaCapi)

    -Con Dijkstra normal, obtenemos los costes mínimos de viajar desde la capital
    hasta cualquier ciudad (en un vector llamado desdeLaCapi)

    -Construimos una matriz M de costes tal que M[i][j]= haciaLaCapi[i]+desdeLaCapi[j]
    Se verifica que esta matriz contiene, en la posición (i,j), el coste mínimo
    de ir desde la ciudad i hacia la ciudad j pasando por la capital.

*/


// Redefinición de nombres: Los vértices son ciudades.
typedef typename GrafoP<unsigned int>::vertice Ciudad;


//función auxiliar: determina si un elemento pertenece a una lista
template<typename T>
bool pertenece(T cc, Lista<T> lis)
{
    return (lis.buscar(cc)!=lis.fin());
}

//Dado un grafo y una lista de vértices, modifica el grafo tal que los vértices pertenecientes al grafo son inaccesibles
template <typename T>
void restringirCiu (GrafoP<T> &G, Lista<Ciudad> &lis)
{
    typename GrafoP<T>::vertice v, w;

    for (v=0; v<G.numVert(); v++)
    {
        if (pertenece(v, lis))
        {
            for (w=0; w<G.numVert(); w++)
                G[w][v]= GrafoP<T>::INFINITO;   //se restringe el acceso desde cualquier vértice hacia el vértice v
        }
    }
}

//Dado un grafo y una matriz de booleanos, restringe los vértices del grafo
template <typename T>
void restringirCar (GrafoP<T> &G, matriz<bool> car)
{
    for (unsigned int v=0; v<G.numVert(); v++)
    {
        for (unsigned int w=0; w<G.numVert(); w++)
        {
            if (car[v][w])                      //car[v][w] contiene true si y solo si la carretera que va desde la ciudad v
                G[v][w]= GrafoP<T>::INFINITO;   //hasta la ciudad w está tomada, y por lo tanto no puede utilizarse
        }
    }

}


int main()
{
    const char* cad= "g3.txt"; // Grafo del que extraeremos el mapa de Zuelandia

    GrafoP<unsigned int> Zuelandia(cad);                    // recibimos el grafo
    Lista<Ciudad> ciudadesT;                                // recibimos la relación de ciudades tomadas por los rebeldes como una lista de vertices
    matriz<bool> carreterasT(Zuelandia.numVert(), false);   // recibimos la relación de las carreteras tomadas
    Ciudad Capital;                                         // recibimos la capital de Zuelandia


// ------ RELLENAMOS LAS EEDD QUE HA DE RECIBIR LA FUNCIÓN: Ciudades tomadas, carreteras tomadas, y capital de Zuelandia -----
    //Se obtiene la lista de ciudades tomadas por los rebeldes:
    Lista<Ciudad>::posicion itCiu= ciudadesT.primera();
    ciudadesT.insertar(0, itCiu);
    ciudadesT.insertar(1, itCiu);

    //Se obtiene la lista de carreteras tomadas por los rebeldes:
    carreterasT[1][2]= true;

    //Se obtiene la capital de Zuelandia:
    Capital=2;
// ------ TERMINAMOS DE RELLENAR TODAS LAS EEDD PEDIDAS ------------------------------------------------


    cout <<"Zuelandia original: "<<Zuelandia<<endl; //Mostramos mapa de Zuelandia original (directamente del fichero .txt)

    restringirCiu(Zuelandia, ciudadesT); // Restringimos las ciudades según la lista de ciudades tomadas
    restringirCar(Zuelandia, carreterasT);// Restringimos las carreteras según la matriz de carreteras tomadas

    cout <<"Zuelandia en guerra: "<<Zuelandia<<endl; //Mostramos el mapa de Zuelandia en guerra (después de restringir ciudades y carreteras)

    // Inicializamos las EEDD necesarias para resolver el problema:
    vector<GrafoP<unsigned int>::vertice> aux(Zuelandia.numVert()); // Vector de vértices. Solo lo necesitamos para pasárselo a los Dijkstra.
    vector<typename GrafoP<unsigned int>::tCoste> haciaLaCapi= DijkstraInv   (Zuelandia, Capital, aux); // Costes mínimos para viajar hacia la capital
    vector<typename GrafoP<unsigned int>::tCoste> desdeLaCapi= Dijkstra      (Zuelandia, Capital, aux); // Costes mínimos para viajar desde la capital

    // Ahora que tenemos todos los datos, construimos la matriz que nos piden y la mostramos:
    matriz<typename GrafoP<unsigned int>::tCoste> costesPedidos(Zuelandia.numVert()); //Matriz de costes pedidos por el enunciado (solución)
    for (unsigned int v=0; v<Zuelandia.numVert(); v++)
        for (unsigned int w=0; w<Zuelandia.numVert(); w++)
            costesPedidos[v][w] = suma(haciaLaCapi[v],desdeLaCapi[w]); //Construimos la matriz pedida


    // Mostramos los vectores devueltos por los algoritmos DijkstraInv y Dijkstra:
    cout << "Costes mínimos para viajar hacia la capital ("<< Capital << ") desde cualquier ciudad:"<<endl;
    cout << haciaLaCapi<<endl;
    cout << "Costes mínimos para viajar desde la capital ("<< Capital << ") hacia cualquier ciudad:"<<endl;
    cout << desdeLaCapi<<endl;

    // Mostramos la solución:
    cout << endl << "Matriz de costes pedida:"<<endl;
    cout << costesPedidos << endl;

    return 0;
}
